<?php
require_once('vendor/autoload.php');

$text = "=====[Pilih Provider Email]=====\n";
$text .= "1. @gmail.com\n";
$text .= "2. @outlook.com\n";
$text .= "3. @hotmail.com\n";
$text .= "4. @yahoo.com\n";
$text .= "================================\n";
echo $text;
$suffix_id = readline("Pilih [1 - 4] : ");
$iterate = readline("Total Generate [nomor] : ");

if ($suffix_id == 1) {
    $suffix = '@gmail.com';
   } elseif ($suffix_id == '2') {
    $suffix = '@outlook.com';
   } elseif ($suffix_id == '3') {
    $suffix = '@hotmail.com';
   } elseif ($suffix_id == '4') {
    $suffix = '@yahoo.com';
   }
$gender = ["male", "female"];

$faker = Faker\Factory::create();

echo "====[List Email Password]====\n";
for ($x = 1 ; $x <= $iterate ; $x++) {

    $gender_1 = $gender[array_rand($gender)];
    $first1 = $faker->firstName($gender_1);
    $first2 = $faker->firstName($gender_1);
    $last = $faker->lastName;
    $password = $faker->regexify('[A-Za-z0-9]{15}');

    echo $first1 . $first2  . $last . $suffix . ' ' .$password . "\n";
}
echo "=============================\n";
